//
//  ViewController.m
//  CarouselMenuDemo
//
//  Created by dsc on 2018/4/8.
//  Copyright © 2018年 jsdtec. All rights reserved.
//

#import "ViewController.h"
#import "CarouselMenuView.h"
@interface ViewController ()<CarouselMenuViewDelegate>

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
      NSDictionary *dic1 = @{@"name":@"大数据",@"image":@"icon_data"};
      NSDictionary *dic2 = @{@"name":@"风口60s",@"image":@"icon_f10"};
      NSDictionary *dic3 = @{@"name":@"f10课堂",@"image":@"icon_fengkou60"};
      NSDictionary *dic4 = @{@"name":@"公开课",@"image":@"icon_gongkai"};
      NSDictionary *dic5 = @{@"name":@"启蒙课",@"image":@"icon_qimeng"};
      NSDictionary *dic6 = @{@"name":@"心态课",@"image":@"icon_xintai"};
      NSDictionary *dic7 = @{@"name":@"大数据",@"image":@"icon_data"};
      NSDictionary *dic8 = @{@"name":@"启蒙课",@"image":@"icon_gongkai"};
      NSDictionary *dic9 = @{@"name":@"公开课",@"image":@"icon_f10"};
      NSDictionary *dic10 = @{@"name":@"f10课堂",@"image":@"icon_xintai"};
      NSDictionary *dic11 = @{@"name":@"启蒙课",@"image":@"icon_data"};
      NSDictionary *dic12 = @{@"name":@"风口60s",@"image":@"icon_qimeng"};
      NSDictionary *dic13 = @{@"name":@"启蒙课",@"image":@"icon_fengkou60"};
      NSDictionary *dic14 = @{@"name":@"风口",@"image":@"icon_gongkai"};
      NSDictionary *dic15 = @{@"name":@"大数据",@"image":@"icon_f10"};
    //此处数据源只为demo展示而用，一般从服务器获取
    NSMutableArray *array = [NSMutableArray arrayWithObjects:dic1,dic2,dic3,dic4,dic5,dic6,dic7,dic8,dic9,dic10,dic11,dic12,dic13,dic14,dic15, nil];
    
    CarouselMenuView *view = [[[NSBundle mainBundle] loadNibNamed:@"CarouselMenuView" owner:self options:nil] lastObject];
    view.dataArray =array;
    view.delegate = self;
    view.frame = CGRectMake(0, 64, [[UIScreen mainScreen] bounds].size.width, 200);
    [self.view addSubview:view];

}
#pragma mark -- 轮播菜单代理实现
- (void)didIndex:(NSInteger)index{
    NSLog(@"%ld",index);
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
