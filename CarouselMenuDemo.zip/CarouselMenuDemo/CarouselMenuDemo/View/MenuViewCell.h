//
//  MenuViewCell.h
//  CarouselMenuDemo
//
//  Created by dsc on 2018/4/8.
//  Copyright © 2018年 jsdtec. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MenuViewCell : UICollectionViewCell<UICollectionViewDataSource,UICollectionViewDelegate>
@property (nonatomic ,weak) IBOutlet UICollectionView *collectionView;
@property (nonatomic ,strong) NSMutableArray *dataArray;
@property (nonatomic, weak)id delegate;
@end
@protocol MenuViewCellDelegate <NSObject>

-(void)didSelectedIndex:(NSIndexPath*)indexPath;

@end
