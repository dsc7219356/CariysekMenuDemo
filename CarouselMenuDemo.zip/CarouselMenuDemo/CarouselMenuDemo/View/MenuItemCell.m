//
//  MenuItemCell.m
//  CarouselMenuDemo
//
//  Created by dsc on 2018/4/8.
//  Copyright © 2018年 jsdtec. All rights reserved.
//

#import "MenuItemCell.h"

@implementation MenuItemCell

- (void)awakeFromNib {
    [super awakeFromNib];
    
}
- (void)cellSetData:(NSDictionary *)dic
{
    self.itemImg.image = [UIImage imageNamed:dic[@"image"]];
    self.nameLab.text = dic[@"name"];
}
@end
