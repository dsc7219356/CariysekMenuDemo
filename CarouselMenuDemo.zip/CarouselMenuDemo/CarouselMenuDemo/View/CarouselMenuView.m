//
//  CarouselMenuView.m
//  CarouselMenuDemo
//
//  Created by dsc on 2018/4/8.
//  Copyright © 2018年 jsdtec. All rights reserved.
//

#import "CarouselMenuView.h"
#import "MenuViewCell.h"
#define MENUVIEWCELL @"MenuViewCell"
@interface CarouselMenuView()<UICollectionViewDataSource,UICollectionViewDelegate,MenuViewCellDelegate>

@property (nonatomic, weak) IBOutlet UICollectionView *collectionView;
@property (nonatomic, weak) IBOutlet UIPageControl *pageControl;
@end
@implementation CarouselMenuView


- (void)awakeFromNib {
    [super awakeFromNib];
    [self.collectionView registerNib:[UINib nibWithNibName:MENUVIEWCELL bundle:nil] forCellWithReuseIdentifier:MENUVIEWCELL];
}

- (void)layoutSubviews{
    [super layoutSubviews];
    //初始化layout
    UICollectionViewFlowLayout *layout = [[UICollectionViewFlowLayout alloc]init];
    layout.itemSize = self.collectionView.bounds.size;
    layout.minimumInteritemSpacing=0;
    layout.minimumLineSpacing=0;
    layout.scrollDirection = UICollectionViewScrollDirectionHorizontal;
    self.collectionView.showsVerticalScrollIndicator=NO;
    self.collectionView.showsHorizontalScrollIndicator=NO;
    self.collectionView.scrollEnabled=YES;
    self.collectionView.collectionViewLayout = layout;
}

#pragma mark -- conllectionViewDelegate
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    NSInteger pageNum = (self.dataArray.count -1)/8 +1;
    self.pageControl.numberOfPages = pageNum;
    return pageNum;
    
}
- (__kindof UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    MenuViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:MENUVIEWCELL forIndexPath:indexPath];

    [self setupCellDataWithCell:cell withIndexPath:indexPath];
    cell.delegate = self;
    return cell;
}
//计算每页item个数
- (void)setupCellDataWithCell:(MenuViewCell *)cell withIndexPath:(NSIndexPath *)index{
    
   
    NSInteger endIndex = (index.item + 1) * 8 - 1;
    if (endIndex > self.dataArray.count - 1) {
        endIndex = self.dataArray.count - 1;
    }
 
    for (NSInteger startIndex = index.item * 8 ; startIndex < endIndex +1; startIndex ++) {
         [cell.dataArray addObject:self.dataArray[startIndex]];
    }
    [cell.collectionView reloadData];
}
//计算currentPage
- (void)scrollViewDidScroll:(UIScrollView *)scrollView{
    self.pageControl.currentPage = (NSInteger)(scrollView.contentOffset.x /scrollView.bounds.size.width);
}
//实现代理
- (void)didSelectedIndex:(NSIndexPath *)indexPath{
    
    if (self.delegate && [self.delegate respondsToSelector:@selector(didIndex:)]) {

        NSInteger index = self.pageControl.currentPage *8 + indexPath.row;
        [self.delegate didIndex:index];
    }
}
@end
