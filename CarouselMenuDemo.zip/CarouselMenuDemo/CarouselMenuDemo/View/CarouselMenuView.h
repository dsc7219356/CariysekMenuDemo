//
//  CarouselMenuView.h
//  CarouselMenuDemo
//
//  Created by dsc on 2018/4/8.
//  Copyright © 2018年 jsdtec. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CarouselMenuView : UIView
@property (nonatomic ,strong) NSMutableArray *dataArray;//数据源
@property (nonatomic ,weak)id delegate;
@end
@protocol CarouselMenuViewDelegate <NSObject>

-(void)didIndex:(NSInteger)index;

@end
