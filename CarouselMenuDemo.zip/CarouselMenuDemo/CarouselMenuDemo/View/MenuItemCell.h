//
//  MenuItemCell.h
//  CarouselMenuDemo
//
//  Created by dsc on 2018/4/8.
//  Copyright © 2018年 jsdtec. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MenuItemCell : UICollectionViewCell
@property (nonatomic, weak) IBOutlet UIImageView *itemImg;
@property (nonatomic, weak) IBOutlet UILabel *nameLab;
- (void)cellSetData:(NSDictionary *)dic;
@end
