//
//  MenuViewCell.m
//  CarouselMenuDemo
//
//  Created by dsc on 2018/4/8.
//  Copyright © 2018年 jsdtec. All rights reserved.
//

#import "MenuViewCell.h"
#import "MenuItemCell.h"

#define MENUITEMCELL @"MenuItemCell"
@implementation MenuViewCell


- (void)awakeFromNib {
    [super awakeFromNib];
    self.dataArray = [NSMutableArray array];
    [self.collectionView registerNib:[UINib nibWithNibName:MENUITEMCELL bundle:nil] forCellWithReuseIdentifier:MENUITEMCELL];
    
}
- (void)layoutSubviews{
    [super layoutSubviews];
    //初始化layout
    UICollectionViewFlowLayout *layout = [[UICollectionViewFlowLayout alloc]init];
    layout.itemSize = CGSizeMake(self.collectionView.bounds.size.width/4, self.collectionView.bounds.size.height/2);
    layout.minimumInteritemSpacing=0;
    layout.minimumLineSpacing=0;
    self.collectionView.scrollEnabled=NO;
    self.collectionView.collectionViewLayout = layout;
}
#pragma mark -- collectionViewDelegate
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    return self.dataArray.count;
}

- (nonnull __kindof UICollectionViewCell *)collectionView:(nonnull UICollectionView *)collectionView cellForItemAtIndexPath:(nonnull NSIndexPath *)indexPath {
    MenuItemCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:MENUITEMCELL forIndexPath:indexPath];
    [cell cellSetData:self.dataArray[indexPath.item]];
    return cell;
}
//实现cell的代理
- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath{
    
    if (self.delegate && [self.delegate respondsToSelector:@selector(didSelectedIndex:)]) {
        [self.delegate didSelectedIndex:indexPath];
    }
}

@end
